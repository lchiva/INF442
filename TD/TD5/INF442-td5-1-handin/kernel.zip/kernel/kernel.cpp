#include <cloud.hpp>
#include <kernel.hpp>

kernel::kernel(cloud *data_)
{
	data = data_;
}
